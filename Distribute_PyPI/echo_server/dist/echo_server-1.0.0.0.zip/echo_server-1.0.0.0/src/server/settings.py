import os

INSTALLED_MODULES = (
    'echo',
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
