from .controllers import echo_controller

action_names = [
    {'action': 'echo', 'controller': echo_controller},
]
